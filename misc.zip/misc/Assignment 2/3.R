iris_independent <- iris[-5]

irisCluster  <- kmeans(iris_independent, 3, iter.max = 1000)

iris_final <- cbind(iris , irisCluster[1])
head(iris_final)

sortedClasses <- rbind(iris[iris$Species=='versicolor',], iris[iris$Species=='setosa',], iris[iris$Species=='virginica',])

table (sortedClasses[,5],irisCluster$cluster)

