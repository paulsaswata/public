mr_data <- read.csv("dataset_multipleRegression.csv")

lm.fit <- lm(ROLL ~ UNEM+HGRAD, mr_data)

test <- data.frame(UNEM=9,HGRAD=100000)

test_result <- predict(lm.fit,test)
test_result
summary (lm.fit)

lm.fit2 <- lm(ROLL ~ UNEM+HGRAD+INC, mr_data)

test2 <- data.frame(UNEM=9,HGRAD=100000, INC=30000)

test_result2 <- predict(lm.fit2,test2)
test_result2
summary(lm.fit2)

