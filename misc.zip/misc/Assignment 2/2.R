library(class)
abalone <- read.csv("abalone.csv")
sampling.rate=0.9
#remainder to test
num_rows <- dim(abalone)[1]
num.test.set.labels=num_rows*(1.-sampling.rate)
#construct a random set of training indices (training)

training <- sample(1:num_rows,sampling.rate*num_rows, replace=FALSE)
length(training)

#build the training set (train)
train<-subset(abalone[training,],select=c(Length,Diameter,Height,Whole.weight,Shucked.weight,Viscera.weight,Shell.weight))
#construct the remaining test indices (testing)
testing<-setdiff(1:num_rows,training)
#define the test set
test<-subset(abalone[testing,],select=c(Length,Diameter,Height,Whole.weight,Shucked.weight,Viscera.weight,Shell.weight))
cg<-abalone$Rings[training]
#construct true labels the other variable in the test set
true.labels<-abalone$Rings[testing]
#run the classifier, can change k
test$predicted <- knn(train,test,cg,k=5)
#view the classifier
test$true.label <- true.labels