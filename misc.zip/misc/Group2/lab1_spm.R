install.packages("car")
require(car)
scatterplotMatrix(iris)
# and
scatterplotMatrix(swiss)
