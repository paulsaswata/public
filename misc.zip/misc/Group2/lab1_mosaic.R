data(HairEyeColor)
mosaicplot(HairEyeColor)
margin.table(HairEyeColor,3)
margin.table(HairEyeColor,c(1,3))
